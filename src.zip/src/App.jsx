import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Stats from './components/Stats';
import About from './components/About';
// import Skills is integrated into About now, or can be kept if we want a separate section. 
// For this design, Skills was requested IN the About section, so we can omit the separate Skills component or keep it if it fits. 
// I will keep the structure clean based on the prompt "About... paired with skill bars".
import Projects from './components/Projects';
import Testimonials from './components/Testimonials';
import CTA from './components/CTA';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
    return (
        <div className="bg-cinema-bg min-h-screen text-white font-sans selection:bg-cinema-orange selection:text-white">
            <Navbar />
            <Hero />
            <Stats />
            <About />
            <Projects />
            <Testimonials />
            <CTA />
            <Contact />
            <Footer />
        </div>
    );
}

export default App;
