import React from 'react';
import { FaGithub, FaExternalLinkAlt } from 'react-icons/fa';

const Projects = () => {
  const projects = [
    {
      title: "ColourDetection",
      description: "Advanced image processing app for real-time color identification using Python & OpenCV.",
      tags: ["Python", "AI/ML", "OpenCV"],
      link: "https://github.com/mohaslam11/ColourDetection",
      type: "AI Research",
      preview: {
        bg: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
        icon: "🎨",
        label: "Computer Vision",
        accent: "#a855f7"
      }
    },
    {
      title: "Platesy App",
      description: "Community-driven food sharing platform promoting zero-waste lifestyle.",
      tags: ["Flutter", "Firebase", "Maps"],
      link: "https://github.com/mohaslam11/platesy-food-sharing",
      type: "Mobile App",
      preview: {
        bg: "linear-gradient(135deg, #134e5e, #71b280)",
        icon: "🍽️",
        label: "Mobile Application",
        accent: "#71b280"
      }
    },
    {
      title: "Medical AI",
      description: "Diagnostic support system leveraging machine learning for fast analysis.",
      tags: ["ML", "Healthcare", "Python"],
      link: "https://github.com/mohaslam11/medical-ai",
      type: "Healthcare Tech",
      preview: {
        bg: "linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)",
        icon: "🩺",
        label: "AI Health Platform",
        accent: "#e94560"
      }
    },
    {
      title: "Travnook Lead Qualifier",
      description: "AI-powered lead qualification system that scores sales leads 0–100 using Groq LLM and exports results to Google Sheets via a Rich terminal UI.",
      tags: ["Python", "Groq API", "Google Sheets"],
      link: "https://github.com/mohaslam11/travnook-lead-qualifier",
      type: "AI Automation",
      preview: {
        bg: "linear-gradient(135deg, #1a1a1a, #2d1b00, #3d2200)",
        icon: "🤖",
        label: "Lead Intelligence",
        accent: "#f97316"
      }
    },
    {
      title: "AI Automation Bot",
      description: "Stealth browser automation bot that bypasses Cloudflare protection using Playwright and puppeteer-extra-stealth with human-like interaction simulation.",
      tags: ["JavaScript", "Playwright", "Automation"],
      link: "https://github.com/mohaslam11/AI-Automation-Bot",
      type: "Browser Automation",
      preview: {
        bg: "linear-gradient(135deg, #0d0d0d, #1a0a2e, #0d1b2a)",
        icon: "⚡",
        label: "Browser Automation",
        accent: "#6366f1"
      }
    }
  ];

  return (
    <section id="projects" className="py-24 bg-cinema-bg">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex justify-between items-end mb-16 border-b border-gray-800 pb-8">
          <div>
            <h4 className="text-cinema-orange font-mono text-sm uppercase tracking-widest mb-2">// Portfolio</h4>
            <h2 className="text-4xl font-black text-white">Featured Work</h2>
          </div>
          <a href="https://github.com/mohaslam11" target="_blank" className="hidden md:flex items-center gap-2 text-gray-500 hover:text-white transition-colors uppercase text-sm font-bold tracking-widest">
            View Github <FaExternalLinkAlt size={12} />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="group relative bg-[#0f0f0f] border border-gray-800 hover:border-cinema-orange transition-all duration-300">
              <div
                className="h-48 relative overflow-hidden border-b border-gray-800"
                style={{ background: project.preview.bg }}
              >
                <div
                  className="absolute inset-0 opacity-10"
                  style={{
                    backgroundImage: `linear-gradient(${project.preview.accent}33 1px, transparent 1px), linear-gradient(90deg, ${project.preview.accent}33 1px, transparent 1px)`,
                    backgroundSize: '30px 30px'
                  }}
                />
                <div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full opacity-20 blur-2xl"
                  style={{ background: project.preview.accent }}
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
                  <span className="text-4xl">{project.preview.icon}</span>
                  <span className="text-xs font-bold uppercase tracking-widest" style={{ color: project.preview.accent }}>
                    {project.preview.label}
                  </span>
                </div>
                <div
                  className="absolute top-3 right-3 text-[10px] font-mono px-2 py-1 border"
                  style={{ color: project.preview.accent, borderColor: `${project.preview.accent}55`, background: `${project.preview.accent}11` }}
                >
                  {'< />'}
                </div>
              </div>

              <div className="p-8">
                <span className="text-cinema-orange text-xs font-bold uppercase tracking-widest mb-2 block">{project.type}</span>
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-cinema-orange transition-colors">{project.title}</h3>
                <p className="text-gray-500 mb-6 text-sm leading-relaxed">{project.description}</p>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2 flex-wrap">
                    {project.tags.map(tag => (
                      <span key={tag} className="text-[10px] uppercase font-bold text-gray-600 border border-gray-800 px-2 py-1">{tag}</span>
                    ))}
                  </div>
                  <a href={project.link} target="_blank" className="text-white hover:text-cinema-orange transition-colors">
                    <FaGithub size={20} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
