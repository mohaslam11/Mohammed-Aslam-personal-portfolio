import React, { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';

const Counter = ({ value, label }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true });
    const [count, setCount] = useState(0);

    useEffect(() => {
        if (isInView) {
            let start = 0;
            const end = parseInt(value, 10);
            if (start === end) return;
            const duration = 2000;
            const incrementTime = (duration / end) * 0.8;

            const timer = setInterval(() => {
                start += 1;
                setCount(start);
                if (start === end) clearInterval(timer);
            }, incrementTime);
        }
    }, [isInView, value]);

    return (
        <div ref={ref} className="text-center p-6 border border-gray-800 bg-[#0f0f0f] hover:border-cinema-orange/50 transition-colors group">
            <h3 className="text-5xl font-black text-white mb-2 group-hover:text-cinema-orange transition-colors">
                {count}{value.includes('+') ? '+' : ''}
            </h3>
            <p className="text-gray-500 uppercase tracking-widest text-xs font-bold">{label}</p>
        </div>
    );
};

const Stats = () => {
    const stats = [
        { value: "02", label: "Years Exp." },
        { value: "15+", label: "Projects Completed" },
        { value: "03", label: "Internships" },
        { value: "08", label: "Technologies" },
    ];

    return (
        <section className="bg-cinema-bg py-12 border-b border-gray-900">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {stats.map((stat, index) => (
                        <Counter key={index} value={stat.value} label={stat.label} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Stats;
