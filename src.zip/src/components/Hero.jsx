import React from 'react';
import { motion } from 'framer-motion';
import { FaDownload, FaArrowRight } from 'react-icons/fa';

const Hero = () => {
    return (
        <section className="relative min-h-screen flex items-center bg-cinema-bg overflow-hidden pt-20">
            {/* Background Texture Overlay */}
            <div className="absolute inset-0 z-0 opacity-20 pointer-events-none"
                style={{ backgroundImage: "url('https://grainy-gradients.vercel.app/noise.svg')" }}>
            </div>

            {/* Geometric Wireframes Overlay (CSS/SVG) */}
            <div className="absolute top-0 right-0 w-1/2 h-full z-0 opacity-10 pointer-events-none hidden lg:block">
                <svg width="100%" height="100%" viewBox="0 0 800 800">
                    <path d="M0,0 L800,800 M800,0 L0,800" stroke="white" strokeWidth="1" />
                    <circle cx="400" cy="400" r="300" stroke="white" strokeWidth="1" fill="none" />
                    <rect x="200" y="200" width="400" height="400" stroke="white" strokeWidth="1" fill="none" />
                </svg>
            </div>

            <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                {/* Left Content */}
                <motion.div
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className="order-2 lg:order-1"
                >
                    <p className="text-cinema-orange font-mono text-sm tracking-[0.2em] mb-4 uppercase">
                        // Hello, I am
                    </p>
                    <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white leading-none mb-6">
                        MOHAMMED <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-500 to-white">
                            ASLAM
                        </span>
                    </h1>
                    <div className="h-1 w-24 bg-cinema-orange mb-8"></div>

                    <h2 className="text-xl md:text-2xl text-gray-400 mb-2 font-light uppercase tracking-wide">
                        Software Application Developer
                    </h2>
                    <p className="text-gray-500 mb-10 font-mono text-sm">
                        [ Flutter ] • [ Android ] • [ iOS ]
                    </p>

                    <div className="flex flex-wrap gap-6">
                        <a
                            href="/Mohammed_Aslam_CV.pdf"
                            download="Mohammed_Aslam_CV.pdf"
                            className="px-8 py-4 bg-cinema-orange text-black font-bold uppercase tracking-widest hover:bg-white transition-all shadow-lg shadow-orange-900/20 flex items-center gap-3 group"
                        >
                            <FaDownload className="group-hover:-translate-y-1 transition-transform" /> Download CV
                        </a>
                        <a
                            href="#projects"
                            className="px-8 py-4 border border-gray-700 text-white font-bold uppercase tracking-widest hover:border-cinema-orange hover:text-cinema-orange transition-all flex items-center gap-3 group"
                        >
                            My Work <FaArrowRight className="group-hover:translate-x-1 transition-transform" />
                        </a>
                    </div>
                </motion.div>

                {/* Right Portrait */}
                <motion.div
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
                    className="order-1 lg:order-2 flex justify-center lg:justify-end relative"
                >
                    {/* Portrait Image */}
                    <div className="relative w-full max-w-lg aspect-[4/5] overflow-hidden">
                        <img
                            src="/profile.png"
                            alt="Mohammed Aslam P A"
                            className="w-full h-full object-cover grayscale opacity-90 hover:grayscale-0 transition-all duration-700 contrast-125"
                        />
                        {/* Overlay Gradient for Fade effect at bottom */}
                        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-cinema-bg to-transparent"></div>
                    </div>

                    {/* Decorative Elements */}
                    <div className="absolute -bottom-6 -right-6 w-24 h-24 border-b-2 border-r-2 border-cinema-orange hidden lg:block"></div>
                </motion.div>
            </div>

            {/* Scroll Indicator */}
            <div className="absolute bottom-10 left-6 lg:left-12 flex items-center gap-4 z-20">
                <div className="w-12 h-[1px] bg-gray-600"></div>
                <span className="text-gray-500 text-xs font-mono uppercase">Scroll Down</span>
            </div>
        </section>
    );
};

export default Hero;
