import React from 'react';

const CTA = () => {
    return (
        <section className="py-24 bg-cinema-orange text-black">
            <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
                <h2 className="text-4xl md:text-6xl font-black mb-8 uppercase tracking-tighter">
                    Available for New <br /> Opportunities
                </h2>
                <p className="text-black/70 mb-10 max-w-2xl mx-auto font-medium text-lg">
                    Looking for a precise and passionate Mobile Application Developer? Let's discuss how I can add value to your team.
                </p>
                <a
                    href="#contact"
                    className="inline-block px-12 py-5 bg-black text-white font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all shadow-2xl"
                >
                    Hire Me Now
                </a>
            </div>
        </section>
    );
};

export default CTA;
