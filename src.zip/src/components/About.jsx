import React from 'react';
import { motion } from 'framer-motion';

const SkillBar = ({ skill, level }) => (
  <div className="mb-6">
    <div className="flex justify-between mb-2">
      <span className="text-white font-bold uppercase text-sm tracking-wider">{skill}</span>
      <span className="text-cinema-orange font-mono text-xs">{level}%</span>
    </div>
    <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        whileInView={{ width: `${level}%` }}
        viewport={{ once: true }}
        transition={{ duration: 1.5, ease: "easeOut" }}
        className="h-full bg-cinema-orange"
      />
    </div>
  </div>
);

const About = () => {
  return (
    <section id="about" className="py-24 bg-cinema-bg text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

          {/* Left: Image */}
          <div className="relative">
            <div className="relative z-10 aspect-video bg-gray-800 grayscale hover:grayscale-0 transition-all duration-500 overflow-hidden shadow-2xl border border-gray-800">
              <img src="/workspace.png" alt="Developer Workspace" className="w-full h-full object-cover" />
            </div>
            {/* Orange Offset Border */}
            <div className="absolute -top-4 -left-4 w-full h-full border border-cinema-orange/30 z-0"></div>
          </div>

          {/* Right: Content */}
          <div>
            <h4 className="text-cinema-orange font-mono text-sm uppercase tracking-widest mb-4">
              // The Journey
            </h4>
            <h2 className="text-3xl md:text-4xl font-black mb-6">
              Building Digital <br />
              <span className="text-gray-500">Excellence.</span>
            </h2>
            <p className="text-gray-400 mb-8 leading-relaxed">
              I am a Software Application Developer based in <span className="text-white font-bold">Dubai, UAE</span>. My journey involves crafting high-performance mobile applications and securing them with robust backend integrations. From real-world internship experiences to learning Cyber Security at <span className="text-white">IIT Jammu</span>, I bring a holistic engineering approach to every project.
            </p>

            <div className="mt-8">
              <SkillBar skill="Flutter" level={90} />
              <SkillBar skill="Android (Kotlin)" level={85} />
              <SkillBar skill="iOS (Swift)" level={75} />
              <SkillBar skill="Backend & Firebase" level={80} />
             <SkillBar skill="Python" level={78} />
             <SkillBar skill="AI Tools & Automation" level={72} />
             <SkillBar skill="Playwright & Browser Automation" level={70} />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default About;
