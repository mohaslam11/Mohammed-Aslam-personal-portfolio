import React from 'react';
import { FaQuoteLeft } from 'react-icons/fa';

const Testimonials = () => {
    return (
        <section id="testimonials" className="py-24 bg-[#0f0f0f] border-y border-gray-900">
            <div className="max-w-4xl mx-auto px-6 text-center">
                <h2 className="text-3xl font-black text-white mb-16 uppercase tracking-widest">
                    Testimonials
                </h2>

                <div className="relative">
                    <FaQuoteLeft className="text-4xl text-gray-800 absolute -top-8 left-0" />
                    <blockquote className="text-2xl md:text-3xl font-light text-gray-300 italic mb-8 relative z-10">
                        "Aslam's ability to translate complex logic into smooth, high-performance mobile interfaces is exceptional. A true professional."
                    </blockquote>
                    <div className="flex items-center justify-center gap-4">
                        <div className="w-12 h-12 bg-gray-700 rounded-full overflow-hidden">
                            {/* Placeholder Avatar */}
                            <div className="w-full h-full bg-gradient-to-br from-gray-600 to-gray-800"></div>
                        </div>
                        <div className="text-left">
                            <cite className="block text-white font-bold not-italic font-mono text-sm">Tech Lead</cite>
                            <span className="text-cinema-orange text-xs font-bold uppercase tracking-wide">Internship Supervisor</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Testimonials;
