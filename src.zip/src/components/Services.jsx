import React from 'react';
import { motion } from 'framer-motion';
import { FaMobileAlt, FaServer, FaCode } from 'react-icons/fa';

const Services = () => {
    const services = [
        {
            icon: <FaMobileAlt className="text-4xl text-neon-cyan" />,
            title: "App Development",
            description: "Native & Cross-platform solutions."
        },
        {
            icon: <FaServer className="text-4xl text-neon-purple" />,
            title: "Backend Tech",
            description: "Scalable integrations & API design."
        },
        {
            icon: <FaCode className="text-4xl text-neon-green" />,
            title: "Prototyping",
            description: "Rapid MVP development for startups."
        }
    ];

    return (
        <section id="services" className="py-24 bg-iridescent-bg">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="mb-12"
                >
                    <h2 className="text-4xl font-black text-white uppercase tracking-tight">Services</h2>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {services.map((service, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className="glass-panel p-8 rounded-2xl hover:bg-white/5 transition-colors group cursor-default"
                        >
                            <div className="mb-6 opacity-80 group-hover:opacity-100 transition-opacity">
                                {service.icon}
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-neon-cyan transition-colors">
                                {service.title}
                            </h3>
                            <p className="text-gray-400">
                                {service.description}
                            </p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;
